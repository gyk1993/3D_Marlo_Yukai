/*
 * Automatically Generated from Mathematica.
 * Mon 19 Dec 2016 02:19:11 GMT-05:00
 */
#include "math2mat.hpp"

/*
 * Sub functions
 */
static void output1(double *p_output1,const double *var)
{
  double t1;
  double t2;
  double t3;
  double t4;
  double t5;
  double t6;
  double t7;
  double t8;
  double t9;
  double t10;
  double t11;
  double t12;
  double t13;
  double t14;
  double t15;
  double t16;
  double t17;
  double t18;
  double t19;
  double t20;
  double t21;
  double t22;
  double t23;
  double t24;
  double t25;
  double t26;
  double t27;
  double t28;
  double t29;
  double t30;
  double t31;
  double t32;
  double t33;
  double t34;
  double t35;
  double t36;
  double t37;
  double t38;
  double t39;
  double t40;
  double t41;
  double t42;
  double t43;
  double t44;
  double t45;
  double t46;
  double t47;
  double t48;
  double t49;
  double t50;
  double t51;
  double t52;
  double t53;
  double t54;
  double t55;
  double t56;
  double t57;
  double t58;
  double t59;
  double t60;
  double t61;
  double t62;
  double t63;
  double t64;
  double t65;
  double t66;
  double t67;
  double t68;
  double t69;
  double t70;
  double t71;
  double t72;
  double t73;
  double t74;
  double t75;
  double t76;
  double t77;
  double t78;
  double t79;
  double t80;
  double t81;
  double t82;
  double t83;
  double t84;
  double t85;
  double t86;
  double t87;
  double t88;
  double t89;
  double t90;
  double t91;
  double t92;
  double t93;
  double t94;
  double t95;
  double t96;
  double t97;
  double t98;
  double t99;
  double t100;
  double t101;
  double t102;
  double t103;
  double t104;
  double t105;
  double t106;
  double t107;
  double t108;
  double t109;
  double t110;
  double t111;
  double t112;
  double t113;
  double t114;
  double t115;
  double t116;
  double t117;
  double t118;
  double t119;
  double t120;
  double t121;
  double t122;
  double t123;
  double t124;
  double t125;
  double t126;
  double t127;
  double t128;
  double t129;
  double t130;
  double t131;
  double t132;
  double t133;
  double t134;
  double t135;
  double t136;
  double t137;
  double t138;
  double t139;
  double t140;
  double t141;
  double t142;
  double t143;
  double t144;
  double t145;
  double t146;
  double t147;
  double t148;
  double t149;
  double t150;
  double t151;
  double t152;
  double t153;
  double t154;
  double t155;
  double t156;
  double t157;
  double t158;
  double t159;
  double t160;
  double t161;
  double t162;
  double t163;
  double t164;
  double t165;
  double t166;
  double t167;
  double t168;
  double t169;
  double t170;
  double t171;
  double t172;
  double t173;
  double t174;
  double t175;
  double t176;
  double t177;
  double t178;
  double t179;
  double t180;
  double t181;
  double t182;
  double t183;
  double t184;
  double t185;
  double t186;
  double t187;
  double t188;
  double t189;
  double t190;
  double t191;
  double t192;
  double t193;
  double t194;
  double t195;
  double t196;
  double t197;
  double t198;
  double t199;
  double t200;
  double t201;
  double t202;
  double t203;
  double t204;
  double t205;
  double t206;
  double t207;
  double t208;
  double t209;
  double t210;
  double t211;
  double t212;
  double t213;
  double t214;
  double t215;
  double t216;
  double t217;
  double t218;
  double t219;
  double t220;
  double t221;
  double t222;
  double t223;
  double t224;
  double t225;
  double t226;
  double t227;
  double t228;
  double t229;
  double t230;
  double t231;
  double t232;
  double t233;
  double t234;
  double t235;
  double t236;
  double t237;
  double t238;
  double t239;
  double t240;
  double t241;
  double t242;
  double t243;
  double t244;
  double t245;
  double t246;
  double t247;
  double t248;
  double t249;
  double t250;
  double t251;
  double t252;
  double t253;
  double t254;
  double t255;
  double t256;
  double t257;
  double t258;
  t1 = var[20];
  t2 = var[21];
  t3 = var[19];
  t4 = Cos(t1);
  t5 = Cos(t2);
  t6 = Sin(t1);
  t7 = Sin(t2);
  t8 = var[18];
  t9 = Cos(t3);
  t10 = t5*t6;
  t11 = t4*t7;
  t12 = t10 + t11;
  t13 = Sin(t3);
  t14 = t4*t5;
  t15 = -1.*t6*t7;
  t16 = t14 + t15;
  t17 = var[17];
  t18 = Cos(t8);
  t19 = -1.*t13*t12;
  t20 = t9*t16;
  t21 = t19 + t20;
  t22 = Sin(t8);
  t23 = t9*t12;
  t24 = t13*t16;
  t25 = t23 + t24;
  t26 = var[15];
  t27 = Cos(t17);
  t28 = t22*t21;
  t29 = t18*t25;
  t30 = t28 + t29;
  t31 = Sin(t17);
  t32 = t18*t21;
  t33 = -1.*t22*t25;
  t34 = t32 + t33;
  t35 = var[14];
  t36 = Cos(t26);
  t37 = var[16];
  t38 = Sin(t37);
  t39 = -1.*t31*t30;
  t40 = t27*t34;
  t41 = t39 + t40;
  t42 = Sin(t26);
  t43 = t27*t30;
  t44 = t31*t34;
  t45 = t43 + t44;
  t46 = var[4];
  t47 = Sin(t35);
  t48 = -1.*t42*t38*t41;
  t49 = t36*t45;
  t50 = t48 + t49;
  t51 = Cos(t35);
  t52 = -1.*t36*t38*t41;
  t53 = -1.*t42*t45;
  t54 = t52 + t53;
  t55 = var[5];
  t56 = -1.*t4*t5;
  t57 = t6*t7;
  t58 = t56 + t57;
  t59 = t13*t12;
  t60 = t9*t58;
  t61 = t59 + t60;
  t62 = -1.*t13*t58;
  t63 = t23 + t62;
  t64 = -1.*t22*t61;
  t65 = t18*t63;
  t66 = t64 + t65;
  t67 = t18*t61;
  t68 = t22*t63;
  t69 = t67 + t68;
  t70 = t31*t66;
  t71 = t27*t69;
  t72 = t70 + t71;
  t73 = t27*t66;
  t74 = -1.*t31*t69;
  t75 = t73 + t74;
  t76 = Sin(t46);
  t77 = Cos(t46);
  t78 = Cos(t37);
  t79 = Cos(t55);
  t80 = -1.*t42*t72;
  t81 = -1.*t36*t38*t75;
  t82 = t80 + t81;
  t83 = t36*t72;
  t84 = -1.*t42*t38*t75;
  t85 = t83 + t84;
  t86 = Sin(t55);
  t87 = -1.*t47*t50;
  t88 = t51*t54;
  t89 = t87 + t88;
  t90 = var[3];
  t91 = t51*t50;
  t92 = t47*t54;
  t93 = t91 + t92;
  t94 = t78*t79*t41;
  t95 = -1.*t89*t86;
  t96 = t94 + t95;
  t97 = Cos(t90);
  t98 = t51*t82;
  t99 = -1.*t47*t85;
  t100 = t98 + t99;
  t101 = Sin(t90);
  t102 = t47*t82;
  t103 = t51*t85;
  t104 = t102 + t103;
  t105 = t78*t79*t75;
  t106 = -1.*t100*t86;
  t107 = t105 + t106;
  t108 = t79*t89;
  t109 = t78*t41*t86;
  t110 = t108 + t109;
  t111 = t77*t93;
  t112 = -1.*t76*t96;
  t113 = t111 + t112;
  t114 = t79*t100;
  t115 = t78*t75*t86;
  t116 = t114 + t115;
  t117 = t77*t104;
  t118 = -1.*t76*t107;
  t119 = t117 + t118;
  t120 = -1.*t5;
  t121 = 1. + t120;
  t122 = -0.0216*t121;
  t123 = 0.0059*t5;
  t124 = 0.0047*t7;
  t125 = t122 + t123 + t124;
  t126 = -1.1135*t121;
  t127 = -1.1182*t5;
  t128 = 0.0275*t7;
  t129 = t126 + t127 + t128;
  t130 = -1.*t4;
  t131 = 1. + t130;
  t132 = 0.0184*t131;
  t133 = -0.7055*t6;
  t134 = t4*t125;
  t135 = -1.*t6*t129;
  t136 = t132 + t133 + t134 + t135;
  t137 = -0.7055*t131;
  t138 = -0.0184*t6;
  t139 = t6*t125;
  t140 = t4*t129;
  t141 = t137 + t138 + t139 + t140;
  t142 = -1.*t18;
  t143 = 1. + t142;
  t144 = -1. + t9;
  t145 = 0.0016*t144;
  t146 = -0.2707*t13;
  t147 = -1.*t13*t141;
  t148 = t9*t136;
  t149 = t145 + t146 + t147 + t148;
  t150 = -1.*t9;
  t151 = 1. + t150;
  t152 = -0.2707*t151;
  t153 = 0.0016*t13;
  t154 = t9*t141;
  t155 = t13*t136;
  t156 = t152 + t153 + t154 + t155;
  t157 = -1.*t78;
  t158 = 1. + t157;
  t159 = -1.*t27;
  t160 = 1. + t159;
  t161 = -0.049*t160;
  t162 = -0.09*t31;
  t163 = -0.21*t143;
  t164 = 0.049*t22;
  t165 = t22*t149;
  t166 = t18*t156;
  t167 = t163 + t164 + t165 + t166;
  t168 = -1.*t31*t167;
  t169 = -0.049*t143;
  t170 = -0.21*t22;
  t171 = t18*t149;
  t172 = -1.*t22*t156;
  t173 = t169 + t170 + t171 + t172;
  t174 = t27*t173;
  t175 = t161 + t162 + t168 + t174;
  t176 = -0.135*t158;
  t177 = -0.1306*t78;
  t178 = -0.049*t38;
  t179 = -1.*t38*t175;
  t180 = t176 + t177 + t178 + t179;
  t181 = -0.09*t160;
  t182 = 0.049*t31;
  t183 = t27*t167;
  t184 = t31*t173;
  t185 = t181 + t182 + t183 + t184;
  t186 = -0.049*t158;
  t187 = 0.0044*t38;
  t188 = t78*t175;
  t189 = t186 + t187 + t188;
  t190 = 0.135*t42;
  t191 = t42*t180;
  t192 = t36*t185;
  t193 = t190 + t191 + t192;
  t194 = -1.*t36;
  t195 = 1. + t194;
  t196 = -0.135*t195;
  t197 = t36*t180;
  t198 = -1.*t42*t185;
  t199 = t196 + t197 + t198;
  t200 = -0.00045*t38;
  t201 = -1.*t38*t189;
  t202 = -1.*t78*t189*t41;
  t203 = t38*t189;
  t204 = t78*t189*t75;
  t205 = t93*t76;
  t206 = t77*t96;
  t207 = t205 + t206;
  t208 = -1.*t51*t36*t78;
  t209 = t78*t47*t42;
  t210 = t208 + t209;
  t211 = -1.*t36*t78*t47;
  t212 = -1.*t51*t78*t42;
  t213 = t211 + t212;
  t214 = t213*t76;
  t215 = -1.*t79*t38;
  t216 = -1.*t210*t86;
  t217 = t215 + t216;
  t218 = t77*t217;
  t219 = t214 + t218;
  t220 = -1.*t51;
  t221 = 1. + t220;
  t222 = -0.135*t221;
  t223 = -1.*t47*t193;
  t224 = t51*t199;
  t225 = t222 + t223 + t224;
  t226 = 0.135*t47;
  t227 = t51*t193;
  t228 = t47*t199;
  t229 = t226 + t227 + t228;
  t230 = t79*t189;
  t231 = -1.*t225*t86;
  t232 = t230 + t231;
  t233 = t79*t225;
  t234 = t189*t86;
  t235 = t233 + t234;
  t236 = t229*t76;
  t237 = t77*t232;
  t238 = t236 + t237;
  t239 = t77*t229;
  t240 = -1.*t76*t232;
  t241 = t239 + t240;
  t242 = t104*t76;
  t243 = t77*t107;
  t244 = t242 + t243;
  t245 = t79*t210;
  t246 = -1.*t38*t86;
  t247 = t245 + t246;
  t248 = t77*t213;
  t249 = -1.*t76*t217;
  t250 = t248 + t249;
  t251 = t247*t235;
  t252 = -1.*t235*t110;
  t253 = -1.*t247*t235;
  t254 = t235*t116;
  t255 = t213*t229;
  t256 = -1.*t229*t93;
  t257 = -1.*t213*t229;
  t258 = t229*t104;
  p_output1[0]=(0.000705*t207 - 0.004125*t244)*(-1.*var[22] + var[44]) + (0.000705*(-1.*t101*t113 + t110*t97) - 0.004125*(-1.*t101*t119 + t116*t97))*(-1.*var[23] + var[45]) + (0.000705*(t101*t110 + t113*t97) - 0.004125*(t101*t116 + t119*t97))*(-1.*var[24] + var[46]) + (0.00045*t219 - 0.004125*(t207*(t219*t238 + t241*t250 + t251) + t219*(-1.*t207*t238 - 1.*t113*t241 + t252)) + 0.000705*(t244*(-1.*t219*t238 - 1.*t241*t250 + t253) + t219*(t119*t241 + t238*t244 + t254)))*(-1.*var[25] + var[47]) + (0.00045*t247 + 0.000705*(t116*(-1.*t217*t232 + t253 + t257) + t247*(t107*t232 + t254 + t258)) - 0.004125*(t110*(t217*t232 + t251 + t255) + t247*(t252 + t256 - 1.*t232*t96)))*(-1.*var[26] + var[48]) + (0.00045*t213 + 0.000705*(t104*(t203 - 1.*t210*t225 + t257) + t213*(t204 + t100*t225 + t258)) - 0.004125*(t213*(t202 + t256 - 1.*t225*t89) + (t201 + t210*t225 + t255)*t93))*(-1.*var[27] + var[49]) + (t200 - 0.004125*(-1.*t38*(t202 - 1.*t193*t50 - 1.*t199*t54) + t41*t78*(t201 - 1.*t199*t36*t78 - 1.*t193*t42*t78) + 0.135*t85) + 0.000705*(0.135*t50 + t75*t78*(t203 + t199*t36*t78 + t193*t42*t78) - 1.*t38*(t204 + t199*t82 + t193*t85)))*(-1.*var[36] + var[58]) + (t200 - 0.004125*(-1.*t38*(t202 + t180*t38*t41 - 1.*t185*t45) + 0.135*t72 + t41*t78*(t201 - 1.*t180*t78)) + 0.000705*(0.135*t45 - 1.*t38*(t204 + t185*t72 - 1.*t180*t38*t75) + t75*t78*(t203 + t180*t78)))*(-1.*var[37] + var[59]) + (0.000705*(0.135*t41 + 0.1306*t72) - 0.004125*(-0.1306*t45 + 0.135*t75))*(-1.*var[38] + var[60]) + (0.00045 - 0.004125*(-1.*t167*t30 - 1.*t173*t34 - 0.09*t66 + 0.049*t69) + 0.000705*(0.049*t30 - 0.09*t34 + t173*t66 + t167*t69))*(-1.*var[39] + var[61]) + (0.00045 - 0.004125*(-1.*t149*t21 - 1.*t156*t25 + 0.049*t61 - 0.21*t63) + 0.000705*(-0.21*t21 + 0.049*t25 + t156*t61 + t149*t63))*(-1.*var[40] + var[62]) + (0.00045 - 0.004125*(-0.2707*t12 - 1.*t12*t141 - 1.*t136*t16 + 0.0016*t58) + 0.000705*(0.0016*t12 + t12*t136 - 0.2707*t16 + t141*t58))*(-1.*var[41] + var[63]) + (0.00045 + 0.000705*(-0.7055*t5 - 1.*t129*t5 - 0.0184*t7 + t125*t7) - 0.004125*(0.0184*t5 - 1.*t125*t5 - 0.7055*t7 - 1.*t129*t7))*(-1.*var[42] + var[64]) + 0.012816751*(-1.*var[43] + var[65]);
}



#ifdef MATLAB_MEX_FILE

#include "mex.h"
#include "matrix.h"

/*
 * Main function
 */
void mexFunction( int nlhs, mxArray *plhs[],
                  int nrhs, const mxArray *prhs[] )
{
  size_t mrows, ncols;

  double *var;
  double *p_output1;

  /*  Check for proper number of arguments.  */ 
  if( nrhs != 1)
    {
      mexErrMsgIdAndTxt("MATLAB:MShaped:invalidNumInputs", "One input(s) required (var).");
    }
  else if( nlhs > 1)
    {
      mexErrMsgIdAndTxt("MATLAB:MShaped:maxlhs", "Too many output arguments.");
    }

  /*  The input must be a noncomplex double vector or scaler.  */
  mrows = mxGetM(prhs[0]);
  ncols = mxGetN(prhs[0]);
  if( !mxIsDouble(prhs[0]) || mxIsComplex(prhs[0]) ||
    ( !(mrows == 66 && ncols == 1) && 
      !(mrows == 1 && ncols == 66))) 
    {
      mexErrMsgIdAndTxt( "MATLAB:MShaped:inputNotRealVector", "var is wrong.");
    }

  /*  Assign pointers to each input.  */
  var = mxGetPr(prhs[0]);
   


   
  /*  Create matrices for return arguments.  */
  plhs[0] = mxCreateDoubleMatrix((mwSize) 1, (mwSize) 1, mxREAL);
  p_output1 = mxGetPr(plhs[0]);


  /* Call the calculation subroutine. */
  output1(p_output1,var);


}

#else // MATLAB_MEX_FILE

#include "f_impactDynamics22.hh"

namespace symbolic_expression
{
namespace basic
{

void f_impactDynamics22_raw(double *p_output1, const double *var)
{
  // Call Subroutines
  output1(p_output1, var);

}

}
}

#endif // MATLAB_MEX_FILE
