/*
 * Automatically Generated from Mathematica.
 * Mon 19 Dec 2016 02:19:07 GMT-05:00
 */
#include "math2mat.hpp"

/*
 * Sub functions
 */
static void output1(double *p_output1,const double *var)
{
  double _NotUsed;
  NULL;
  p_output1[0]=1.;
  p_output1[1]=1.;
  p_output1[2]=1.;
  p_output1[3]=1.;
  p_output1[4]=1.;
  p_output1[5]=1.;
  p_output1[6]=1.;
  p_output1[7]=1.;
  p_output1[8]=1.;
  p_output1[9]=1.;
  p_output1[10]=1.;
  p_output1[11]=1.;
  p_output1[12]=1.;
  p_output1[13]=1.;
  p_output1[14]=1.;
  p_output1[15]=1.;
  p_output1[16]=1.;
  p_output1[17]=1.;
  p_output1[18]=1.;
  p_output1[19]=1.;
  p_output1[20]=1.;
  p_output1[21]=1.;
  p_output1[22]=1.;
  p_output1[23]=1.;
  p_output1[24]=1.;
  p_output1[25]=1.;
  p_output1[26]=1.;
  p_output1[27]=1.;
  p_output1[28]=1.;
  p_output1[29]=1.;
  p_output1[30]=1.;
  p_output1[31]=1.;
  p_output1[32]=1.;
  p_output1[33]=1.;
  p_output1[34]=1.;
  p_output1[35]=1.;
  p_output1[36]=1.;
  p_output1[37]=1.;
  p_output1[38]=1.;
  p_output1[39]=4.;
  p_output1[40]=5.;
  p_output1[41]=6.;
  p_output1[42]=15.;
  p_output1[43]=16.;
  p_output1[44]=17.;
  p_output1[45]=18.;
  p_output1[46]=19.;
  p_output1[47]=20.;
  p_output1[48]=21.;
  p_output1[49]=22.;
  p_output1[50]=23.;
  p_output1[51]=24.;
  p_output1[52]=25.;
  p_output1[53]=26.;
  p_output1[54]=27.;
  p_output1[55]=28.;
  p_output1[56]=37.;
  p_output1[57]=38.;
  p_output1[58]=39.;
  p_output1[59]=40.;
  p_output1[60]=41.;
  p_output1[61]=42.;
  p_output1[62]=43.;
  p_output1[63]=44.;
  p_output1[64]=45.;
  p_output1[65]=46.;
  p_output1[66]=47.;
  p_output1[67]=48.;
  p_output1[68]=49.;
  p_output1[69]=50.;
  p_output1[70]=59.;
  p_output1[71]=60.;
  p_output1[72]=61.;
  p_output1[73]=62.;
  p_output1[74]=63.;
  p_output1[75]=64.;
  p_output1[76]=65.;
  p_output1[77]=66.;
}



#ifdef MATLAB_MEX_FILE

#include "mex.h"
#include "matrix.h"

/*
 * Main function
 */
void mexFunction( int nlhs, mxArray *plhs[],
                  int nrhs, const mxArray *prhs[] )
{
  size_t mrows, ncols;

  double *var;
  double *p_output1;

  /*  Check for proper number of arguments.  */ 
  if( nrhs != 1)
    {
      mexErrMsgIdAndTxt("MATLAB:MShaped:invalidNumInputs", "One input(s) required (var).");
    }
  else if( nlhs > 1)
    {
      mexErrMsgIdAndTxt("MATLAB:MShaped:maxlhs", "Too many output arguments.");
    }

  /*  The input must be a noncomplex double vector or scaler.  */
  mrows = mxGetM(prhs[0]);
  ncols = mxGetN(prhs[0]);
  if( !mxIsDouble(prhs[0]) || mxIsComplex(prhs[0]) ||
    ( !(mrows == 1 && ncols == 1) && 
      !(mrows == 1 && ncols == 1))) 
    {
      mexErrMsgIdAndTxt( "MATLAB:MShaped:inputNotRealVector", "var is wrong.");
    }

  /*  Assign pointers to each input.  */
  var = mxGetPr(prhs[0]);
   


   
  /*  Create matrices for return arguments.  */
  plhs[0] = mxCreateDoubleMatrix((mwSize) 39, (mwSize) 2, mxREAL);
  p_output1 = mxGetPr(plhs[0]);


  /* Call the calculation subroutine. */
  output1(p_output1,var);


}

#else // MATLAB_MEX_FILE

#include "Js_impactDynamics19.hh"

namespace symbolic_expression
{
namespace basic
{

void Js_impactDynamics19_raw(double *p_output1, const double *var)
{
  // Call Subroutines
  output1(p_output1, var);

}

}
}

#endif // MATLAB_MEX_FILE
