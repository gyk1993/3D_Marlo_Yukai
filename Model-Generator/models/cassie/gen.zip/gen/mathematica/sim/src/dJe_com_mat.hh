/*
 * Automatically Generated from Mathematica.
 * Sun 18 Dec 2016 22:57:45 GMT-05:00
 */
#include <Eigen/Dense>

#ifdef MATLAB_MEX_FILE
// No need for external definitions
#else // MATLAB_MEX_FILE

namespace symbolic_expression
{
  namespace basic
  {

    void dJe_com_mat_raw(double *p_output1, double *p_output2, double *p_output3, const double *x);

    inline void dJe_com_mat(Eigen::MatrixXd &p_output1, Eigen::MatrixXd &p_output2, Eigen::MatrixXd &p_output3, const Eigen::VectorXd &x)
    {
      // Check
      // - Inputs
      assert_size_matrix(x, 44, 1);

	
      // - Outputs
      assert_size_matrix(p_output1, 22, 1);
assert_size_matrix(p_output2, 22, 1);
assert_size_matrix(p_output3, 22, 1);


      // set zero the matrix
      p_output1.setZero();
p_output2.setZero();
p_output3.setZero();


      // Call Subroutine with raw data
      dJe_com_mat_raw(p_output1.data(), p_output2.data(), p_output3.data(), x.data());
    }
  
  }
}

#endif // MATLAB_MEX_FILE
