/*
 * Automatically Generated from Mathematica.
 * Sun 18 Dec 2016 22:59:02 GMT-05:00
 */
#include "math2mat.hpp"

/*
 * Sub functions
 */
static void output1(double *p_output1,const double *x)
{
  double t1;
  double t2;
  double t3;
  double t4;
  double t5;
  double t6;
  double t7;
  double t8;
  double t9;
  double t10;
  double t11;
  double t12;
  double t13;
  double t14;
  double t15;
  double t16;
  double t17;
  double t18;
  double t19;
  double t20;
  double t21;
  double t22;
  double t23;
  double t24;
  double t25;
  double t26;
  double t27;
  double t28;
  double t29;
  double t30;
  double t31;
  double t32;
  double t33;
  double t34;
  double t35;
  double t36;
  double t37;
  double t38;
  double t39;
  double t40;
  double t41;
  double t42;
  double t43;
  double t44;
  double t45;
  double t46;
  double t47;
  double t48;
  double t49;
  double t50;
  double t51;
  double t52;
  double t53;
  double t54;
  double t55;
  double t56;
  double t57;
  double t58;
  double t59;
  double t60;
  double t61;
  double t62;
  double t63;
  double t64;
  double t65;
  double t66;
  double t67;
  double t68;
  double t69;
  double t70;
  double t71;
  double t72;
  double t73;
  double t74;
  double t75;
  double t76;
  double t77;
  double t78;
  double t79;
  double t80;
  double t81;
  double t82;
  double t83;
  double t84;
  double t85;
  double t86;
  double t87;
  double t88;
  double t89;
  double t90;
  double t91;
  double t92;
  double t93;
  double t94;
  double t95;
  double t96;
  double t97;
  double t98;
  double t99;
  double t100;
  double t101;
  double t102;
  double t103;
  double t104;
  double t105;
  double t106;
  double t107;
  double t108;
  double t109;
  double t110;
  double t111;
  double t112;
  double t113;
  double t114;
  double t115;
  double t116;
  double t117;
  double t118;
  double t119;
  double t120;
  double t121;
  double t122;
  double t123;
  double t124;
  double t125;
  double t126;
  double t127;
  double t128;
  double t129;
  double t130;
  double t131;
  double t132;
  double t133;
  double t134;
  double t135;
  double t136;
  double t137;
  double t138;
  double t139;
  double t140;
  double t141;
  double t142;
  double t143;
  double t144;
  double t145;
  t1 = x[14];
  t2 = x[3];
  t3 = Sin(t2);
  t4 = x[4];
  t5 = x[5];
  t6 = Cos(t5);
  t7 = Sin(t4);
  t8 = Cos(t2);
  t9 = Sin(t5);
  t10 = x[25];
  t11 = Cos(t4);
  t12 = x[27];
  t13 = Sin(t1);
  t14 = Cos(t1);
  t15 = x[26];
  t16 = t8*t6;
  t17 = -1.*t3*t7*t9;
  t18 = t16 + t17;
  t19 = x[36];
  t20 = -1.*t6*t3;
  t21 = -1.*t8*t7*t9;
  t22 = t20 + t21;
  t23 = t8*t6*t7*t10;
  t24 = -1.*t3*t9*t10;
  t25 = t11*t6*t3*t15;
  t26 = t8*t6*t12;
  t27 = -1.*t3*t7*t9*t12;
  t28 = t23 + t24 + t25 + t26 + t27;
  t29 = -1.*t6*t3*t10;
  t30 = -1.*t8*t7*t9*t10;
  t31 = -1.*t11*t3*t9*t15;
  t32 = -1.*t6*t3*t7*t12;
  t33 = -1.*t8*t9*t12;
  t34 = t29 + t30 + t31 + t32 + t33;
  t35 = t6*t3*t7;
  t36 = t8*t9;
  t37 = t35 + t36;
  t38 = t6*t3;
  t39 = t8*t7*t9;
  t40 = t38 + t39;
  t41 = -1.*t14*t11*t3*t19;
  t42 = -1.*t13*t18*t19;
  t43 = -1.*t8*t11*t13*t10;
  t44 = t13*t3*t7*t15;
  t45 = t14*t34;
  t46 = t41 + t42 + t43 + t44 + t45;
  t47 = -1.*t11*t13*t3*t19;
  t48 = t14*t18*t19;
  t49 = t14*t8*t11*t10;
  t50 = -1.*t14*t3*t7*t15;
  t51 = t13*t34;
  t52 = t47 + t48 + t49 + t50 + t51;
  t53 = t14*t11*t3;
  t54 = t13*t18;
  t55 = t53 + t54;
  t56 = t8*t6*t10;
  t57 = -1.*t3*t7*t9*t10;
  t58 = t8*t11*t9*t15;
  t59 = t8*t6*t7*t12;
  t60 = -1.*t3*t9*t12;
  t61 = t56 + t57 + t58 + t59 + t60;
  t62 = -1.*t11*t13*t3;
  t63 = t14*t18;
  t64 = t62 + t63;
  t65 = -1.*t8*t6*t10;
  t66 = t3*t7*t9*t10;
  t67 = -1.*t8*t11*t9*t15;
  t68 = -1.*t8*t6*t7*t12;
  t69 = t3*t9*t12;
  t70 = t65 + t66 + t67 + t68 + t69;
  t71 = t11*t13;
  t72 = t14*t7*t9;
  t73 = t71 + t72;
  t74 = -1.*t8*t6*t7;
  t75 = t3*t9;
  t76 = t74 + t75;
  t77 = t6*t3*t7*t10;
  t78 = t8*t9*t10;
  t79 = -1.*t8*t11*t6*t15;
  t80 = t6*t3*t12;
  t81 = t8*t7*t9*t12;
  t82 = t77 + t78 + t79 + t80 + t81;
  t83 = -1.*t14*t8*t11;
  t84 = t13*t40;
  t85 = t83 + t84;
  t86 = -1.*t14*t7;
  t87 = -1.*t11*t13*t9;
  t88 = t86 + t87;
  t89 = t8*t11*t13*t19;
  t90 = t14*t40*t19;
  t91 = t14*t11*t3*t10;
  t92 = t14*t8*t7*t15;
  t93 = t13*t61;
  t94 = t89 + t90 + t91 + t92 + t93;
  t95 = t8*t11*t13;
  t96 = t14*t40;
  t97 = t95 + t96;
  t98 = t14*t8*t11*t19;
  t99 = -1.*t13*t40*t19;
  t100 = -1.*t11*t13*t3*t10;
  t101 = -1.*t8*t13*t7*t15;
  t102 = t14*t61;
  t103 = t98 + t99 + t100 + t101 + t102;
  t104 = t8*t6*t7;
  t105 = -1.*t3*t9;
  t106 = t104 + t105;
  t107 = Power(t6,2);
  t108 = Power(t11,2);
  t109 = -1.*t6*t3*t7*t10;
  t110 = -1.*t8*t9*t10;
  t111 = t8*t11*t6*t15;
  t112 = -1.*t6*t3*t12;
  t113 = -1.*t8*t7*t9*t12;
  t114 = t109 + t110 + t111 + t112 + t113;
  t115 = -1.*t6*t3*t7;
  t116 = -1.*t8*t9;
  t117 = t115 + t116;
  t118 = t13*t7*t19;
  t119 = -1.*t14*t11*t9*t19;
  t120 = -1.*t14*t11*t15;
  t121 = t13*t7*t9*t15;
  t122 = -1.*t11*t6*t13*t12;
  t123 = t118 + t119 + t120 + t121 + t122;
  t124 = t13*t7;
  t125 = -1.*t14*t11*t9;
  t126 = t124 + t125;
  t127 = t14*t7*t19;
  t128 = t11*t13*t9*t19;
  t129 = t11*t13*t15;
  t130 = t14*t7*t9*t15;
  t131 = -1.*t14*t11*t6*t12;
  t132 = t127 + t128 + t129 + t130 + t131;
  t133 = -1.*t8*t6*t7*t10;
  t134 = t3*t9*t10;
  t135 = -1.*t11*t6*t3*t15;
  t136 = -1.*t8*t6*t12;
  t137 = t3*t7*t9*t12;
  t138 = t133 + t134 + t135 + t136 + t137;
  t139 = t14*t7;
  t140 = t11*t13*t9;
  t141 = t139 + t140;
  t142 = t14*t8*t11;
  t143 = -1.*t8*t11*t13*t19;
  t144 = -1.*t14*t11*t3*t10;
  t145 = -1.*t14*t8*t7*t15;
  p_output1[9]=t46*t76 + t28*(t14*t22 - 1.*t11*t13*t8) + t37*(-1.*t13*t19*t22 + t10*t11*t13*t3 + t14*t70 - 1.*t11*t14*t19*t8 + t13*t15*t7*t8) + t64*t82;
  p_output1[10]=t106*t52 + t114*t55 + t28*t85 + t37*t94;
  p_output1[11]=(t142 + t13*t22)*t46 + t103*t55 + t64*(t143 + t144 + t145 + t14*t19*t22 + t13*t70) + t52*t97;
  p_output1[12]=-1.*t15*t6*t7*t73 - 1.*t11*t12*t73*t9 + t28*(t13*t3*t7 - 1.*t11*t14*t3*t9) + t11*t6*(t11*t14*t19 - 1.*t13*t15*t7 + t12*t14*t6*t7 + t11*t14*t15*t9 - 1.*t13*t19*t7*t9) + t82*(-1.*t13*t7*t8 + t11*t14*t8*t9) + t37*(t11*t13*t15*t3 - 1.*t11*t12*t14*t3*t6 + t14*t19*t3*t7 + t10*t13*t7*t8 + t11*t13*t19*t3*t9 + t14*t15*t3*t7*t9 - 1.*t10*t11*t14*t8*t9) + t76*(t10*t13*t3*t7 - 1.*t11*t13*t15*t8 + t11*t12*t14*t6*t8 - 1.*t14*t19*t7*t8 - 1.*t10*t11*t14*t3*t9 - 1.*t11*t13*t19*t8*t9 - 1.*t14*t15*t7*t8*t9);
  p_output1[13]=t11*t3*t52*t6 - 1.*t123*t6*t7 - 1.*t15*t3*t55*t6*t7 + t10*t11*t55*t6*t8 + t10*t11*t3*t6*t85 + t15*t6*t7*t8*t85 - 1.*t11*t15*t6*t88 - 1.*t11*t12*t3*t55*t9 + t11*t12*t8*t85*t9 + t12*t7*t88*t9 - 1.*t11*t6*t8*t94;
  p_output1[14]=t46*(-1.*t14*t3*t7 - 1.*t11*t13*t3*t9) + t132*(-1.*t11*t14 + t13*t7*t9) + t126*(t11*t13*t19 + t14*t15*t7 + t12*t13*t6*t7 + t11*t13*t15*t9 + t14*t19*t7*t9) + t103*(t14*t7*t8 + t11*t13*t8*t9) + t64*(-1.*t11*t14*t15*t3 - 1.*t11*t12*t13*t3*t6 + t13*t19*t3*t7 - 1.*t10*t14*t7*t8 - 1.*t11*t14*t19*t3*t9 + t13*t15*t3*t7*t9 - 1.*t10*t11*t13*t8*t9) + (-1.*t10*t14*t3*t7 + t11*t14*t15*t8 + t11*t12*t13*t6*t8 - 1.*t13*t19*t7*t8 - 1.*t10*t11*t13*t3*t9 + t11*t14*t19*t8*t9 - 1.*t13*t15*t7*t8*t9)*t97;
  p_output1[15]=t107*t108*t13*t19 + t117*t14*t28 + t138*t14*t37 - 1.*t117*t13*t19*t37 + 2.*t107*t11*t14*t15*t7 + t114*t14*t76 - 1.*t106*t13*t19*t76 + t106*t14*t82 + 2.*t108*t12*t14*t6*t9;
  p_output1[16]=t18*t52 + t34*t55 + t61*t85 - 1.*t11*t12*t6*t88 - 1.*t11*t123*t9 + t15*t7*t88*t9 + t40*t94;
  p_output1[17]=t103*t106*t13 + t117*t13*t46 - 1.*t11*t13*t132*t6 - 1.*t11*t126*t14*t19*t6 + t13*t138*t64 + t117*t14*t19*t64 + t126*t13*t15*t6*t7 + t11*t12*t126*t13*t9 + t114*t13*t97 + t106*t14*t19*t97;
  p_output1[42]=t28*(-1.*t13*t18 - 1.*t11*t14*t3) - 1.*t141*t15*t6*t7 + (t143 + t144 + t145 - 1.*t14*t19*t40 - 1.*t13*t61)*t76 + t37*(-1.*t14*t18*t19 + t11*t13*t19*t3 - 1.*t13*t34 + t14*t15*t3*t7 - 1.*t10*t11*t14*t8) + (t142 - 1.*t13*t40)*t82 - 1.*t11*t12*t141*t9 + t11*t6*(t11*t14*t15 + t11*t12*t13*t6 - 1.*t13*t19*t7 + t11*t14*t19*t9 - 1.*t13*t15*t7*t9);
  p_output1[44]=2.*t126*t132 + 2.*t46*t64 + 2.*t103*t97;
}



#ifdef MATLAB_MEX_FILE

#include "mex.h"
#include "matrix.h"

/*
 * Main function
 */
void mexFunction( int nlhs, mxArray *plhs[],
                  int nrhs, const mxArray *prhs[] )
{
  size_t mrows, ncols;

  double *x;
  double *p_output1;

  /*  Check for proper number of arguments.  */ 
  if( nrhs != 1)
    {
      mexErrMsgIdAndTxt("MATLAB:MShaped:invalidNumInputs", "One input(s) required (x).");
    }
  else if( nlhs > 1)
    {
      mexErrMsgIdAndTxt("MATLAB:MShaped:maxlhs", "Too many output arguments.");
    }

  /*  The input must be a noncomplex double vector or scaler.  */
  mrows = mxGetM(prhs[0]);
  ncols = mxGetN(prhs[0]);
  if( !mxIsDouble(prhs[0]) || mxIsComplex(prhs[0]) ||
    ( !(mrows == 44 && ncols == 1) && 
      !(mrows == 1 && ncols == 44))) 
    {
      mexErrMsgIdAndTxt( "MATLAB:MShaped:inputNotRealVector", "x is wrong.");
    }

  /*  Assign pointers to each input.  */
  x = mxGetPr(prhs[0]);
   


   
  /*  Create matrices for return arguments.  */
  plhs[0] = mxCreateDoubleMatrix((mwSize) 3, (mwSize) 22, mxREAL);
  p_output1 = mxGetPr(plhs[0]);


  /* Call the calculation subroutine. */
  output1(p_output1,x);


}

#else // MATLAB_MEX_FILE

#include "dJw_body_fixedright.hh"

namespace symbolic_expression
{
namespace basic
{

void dJw_body_fixedright_raw(double *p_output1, const double *x)
{
  // Call Subroutines
  output1(p_output1, x);

}

}
}

#endif // MATLAB_MEX_FILE
