/*
 * Automatically Generated from Mathematica.
 * Sun 18 Dec 2016 22:59:06 GMT-05:00
 */
#include <Eigen/Dense>

#ifdef MATLAB_MEX_FILE
// No need for external definitions
#else // MATLAB_MEX_FILE

namespace symbolic_expression
{
  namespace basic
  {

    void dJw_body_hipflexionright_raw(double *p_output1, const double *x);

    inline void dJw_body_hipflexionright(Eigen::MatrixXd &p_output1, const Eigen::VectorXd &x)
    {
      // Check
      // - Inputs
      assert_size_matrix(x, 44, 1);

	
      // - Outputs
      assert_size_matrix(p_output1, 3, 22);


      // set zero the matrix
      p_output1.setZero();


      // Call Subroutine with raw data
      dJw_body_hipflexionright_raw(p_output1.data(), x.data());
    }
  
  }
}

#endif // MATLAB_MEX_FILE
