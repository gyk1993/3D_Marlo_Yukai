/*
 * Automatically Generated from Mathematica.
 * Sun 18 Dec 2016 22:58:04 GMT-05:00
 */
#include "math2mat.hpp"

/*
 * Sub functions
 */
static void output1(double *p_output1,const double *x)
{
  double t1;
  double t2;
  double t3;
  double t4;
  double t5;
  double t6;
  double t7;
  double t8;
  double t9;
  double t10;
  double t11;
  double t12;
  double t13;
  double t14;
  double t15;
  double t16;
  double t17;
  double t18;
  double t19;
  double t20;
  double t21;
  double t22;
  double t23;
  double t24;
  double t25;
  double t26;
  double t27;
  double t28;
  double t29;
  double t30;
  double t31;
  double t32;
  double t33;
  double t34;
  double t35;
  double t36;
  double t37;
  double t38;
  double t39;
  double t40;
  double t41;
  double t42;
  double t43;
  double t44;
  double t45;
  double t46;
  double t47;
  double t48;
  double t49;
  double t50;
  double t51;
  double t52;
  double t53;
  double t54;
  double t55;
  double t56;
  double t57;
  double t58;
  double t59;
  double t60;
  double t61;
  double t62;
  double t63;
  double t64;
  double t65;
  double t66;
  double t67;
  double t68;
  double t69;
  double t70;
  double t71;
  double t72;
  double t73;
  double t74;
  double t75;
  double t76;
  double t77;
  double t78;
  double t79;
  double t80;
  double t81;
  double t82;
  double t83;
  double t84;
  double t85;
  double t86;
  double t87;
  double t88;
  double t89;
  double t90;
  double t91;
  double t92;
  double t93;
  double t94;
  double t95;
  double t96;
  double t97;
  double t98;
  double t99;
  double t100;
  double t101;
  double t102;
  double t103;
  double t104;
  double t105;
  double t106;
  double t107;
  double t108;
  double t109;
  double t110;
  double t111;
  double t112;
  double t113;
  double t114;
  double t115;
  double t116;
  double t117;
  double t118;
  double t119;
  double t120;
  double t121;
  double t122;
  double t123;
  double t124;
  double t125;
  double t126;
  double t127;
  double t128;
  double t129;
  double t130;
  double t131;
  double t132;
  double t133;
  double t134;
  double t135;
  double t136;
  double t137;
  double t138;
  double t139;
  double t140;
  double t141;
  double t142;
  double t143;
  double t144;
  double t145;
  double t146;
  double t147;
  double t148;
  double t149;
  double t150;
  double t151;
  double t152;
  double t153;
  double t154;
  double t155;
  double t156;
  double t157;
  double t158;
  double t159;
  double t160;
  double t161;
  double t162;
  double t163;
  double t164;
  double t165;
  double t166;
  double t167;
  double t168;
  double t169;
  double t170;
  double t171;
  double t172;
  double t173;
  double t174;
  double t175;
  double t176;
  double t177;
  double t178;
  double t179;
  double t180;
  double t181;
  double t182;
  double t183;
  double t184;
  double t185;
  double t186;
  double t187;
  double t188;
  double t189;
  double t190;
  double t191;
  double t192;
  double t193;
  double t194;
  double t195;
  double t196;
  double t197;
  double t198;
  double t199;
  double t200;
  double t201;
  double t202;
  double t203;
  double t204;
  double t205;
  double t206;
  double t207;
  double t208;
  double t209;
  double t210;
  double t211;
  double t212;
  double t213;
  double t214;
  double t215;
  double t216;
  double t217;
  double t218;
  double t219;
  double t220;
  double t221;
  double t222;
  double t223;
  double t224;
  double t225;
  double t226;
  double t227;
  double t228;
  double t229;
  double t230;
  double t231;
  double t232;
  double t233;
  double t234;
  double t235;
  double t236;
  double t237;
  double t238;
  double t239;
  double t240;
  double t241;
  double t242;
  double t243;
  double t244;
  double t245;
  double t246;
  double t247;
  double t248;
  double t249;
  double t250;
  double t251;
  double t252;
  double t253;
  double t254;
  double t255;
  double t256;
  double t257;
  double t258;
  double t259;
  double t260;
  double t261;
  double t262;
  double t263;
  double t264;
  double t265;
  double t266;
  double t267;
  double t268;
  double t269;
  double t270;
  double t271;
  double t272;
  double t273;
  double t274;
  double t275;
  double t276;
  double t277;
  double t278;
  double t279;
  double t280;
  double t281;
  double t282;
  double t283;
  double t284;
  double t285;
  double t286;
  double t287;
  double t288;
  double t289;
  double t290;
  double t291;
  double t292;
  double t293;
  double t294;
  double t295;
  double t296;
  double t297;
  double t298;
  double t299;
  double t300;
  double t301;
  double t302;
  double t303;
  double t304;
  double t305;
  double t306;
  double t307;
  t1 = x[6];
  t2 = x[3];
  t3 = Cos(t2);
  t4 = x[4];
  t5 = x[5];
  t6 = x[7];
  t7 = Cos(t1);
  t8 = Cos(t4);
  t9 = Sin(t1);
  t10 = Cos(t5);
  t11 = Sin(t2);
  t12 = -1.*t10*t11;
  t13 = Sin(t4);
  t14 = Sin(t5);
  t15 = -1.*t3*t13*t14;
  t16 = t12 + t15;
  t17 = Cos(t6);
  t18 = Sin(t6);
  t19 = t3*t10;
  t20 = -1.*t11*t13*t14;
  t21 = t19 + t20;
  t22 = x[29];
  t23 = x[28];
  t24 = x[25];
  t25 = x[26];
  t26 = x[27];
  t27 = -1.*t10*t11*t24;
  t28 = -1.*t3*t13*t14*t24;
  t29 = -1.*t8*t11*t14*t25;
  t30 = -1.*t10*t11*t13*t26;
  t31 = -1.*t3*t14*t26;
  t32 = t27 + t28 + t29 + t30 + t31;
  t33 = t10*t11;
  t34 = t3*t13*t14;
  t35 = t33 + t34;
  t36 = -1.*t8*t9*t11;
  t37 = t7*t21;
  t38 = t36 + t37;
  t39 = -1.*t7*t8*t11;
  t40 = -1.*t9*t21;
  t41 = t39 + t40;
  t42 = -1.*t7*t8*t11*t23;
  t43 = -1.*t9*t21*t23;
  t44 = -1.*t3*t8*t9*t24;
  t45 = t9*t11*t13*t25;
  t46 = t7*t32;
  t47 = t42 + t43 + t44 + t45 + t46;
  t48 = t8*t9*t11*t23;
  t49 = -1.*t7*t21*t23;
  t50 = -1.*t7*t3*t8*t24;
  t51 = t7*t11*t13*t25;
  t52 = -1.*t9*t32;
  t53 = t48 + t49 + t50 + t51 + t52;
  t54 = t3*t8*t9;
  t55 = t7*t35;
  t56 = t54 + t55;
  t57 = t7*t3*t8;
  t58 = -1.*t9*t35;
  t59 = t57 + t58;
  t60 = t3*t10*t24;
  t61 = -1.*t11*t13*t14*t24;
  t62 = t3*t8*t14*t25;
  t63 = t3*t10*t13*t26;
  t64 = -1.*t11*t14*t26;
  t65 = t60 + t61 + t62 + t63 + t64;
  t66 = -1.*t3*t8*t9;
  t67 = t7*t16;
  t68 = t66 + t67;
  t69 = -1.*t7*t3*t8;
  t70 = -1.*t9*t16;
  t71 = t69 + t70;
  t72 = -1.*t3*t10*t24;
  t73 = t11*t13*t14*t24;
  t74 = -1.*t3*t8*t14*t25;
  t75 = -1.*t3*t10*t13*t26;
  t76 = t11*t14*t26;
  t77 = t72 + t73 + t74 + t75 + t76;
  t78 = -1.*t18*t38;
  t79 = t17*t41;
  t80 = t78 + t79;
  t81 = -1.*t17*t38*t22;
  t82 = -1.*t18*t41*t22;
  t83 = -1.*t18*t47;
  t84 = t17*t53;
  t85 = t81 + t82 + t83 + t84;
  t86 = -1.*t7*t3*t8*t23;
  t87 = -1.*t9*t16*t23;
  t88 = t8*t9*t11*t24;
  t89 = t3*t9*t13*t25;
  t90 = t7*t77;
  t91 = t86 + t87 + t88 + t89 + t90;
  t92 = t3*t8*t9*t23;
  t93 = -1.*t7*t16*t23;
  t94 = t7*t8*t11*t24;
  t95 = t7*t3*t13*t25;
  t96 = -1.*t9*t77;
  t97 = t92 + t93 + t94 + t95 + t96;
  t98 = t17*t38;
  t99 = t18*t41;
  t100 = t98 + t99;
  t101 = t3*t10*t13*t24;
  t102 = -1.*t11*t14*t24;
  t103 = t8*t10*t11*t25;
  t104 = t3*t10*t26;
  t105 = -1.*t11*t13*t14*t26;
  t106 = t101 + t102 + t103 + t104 + t105;
  t107 = -1.*t18*t38*t22;
  t108 = t17*t41*t22;
  t109 = t17*t47;
  t110 = t18*t53;
  t111 = t107 + t108 + t109 + t110;
  t112 = t10*t11*t13;
  t113 = t3*t14;
  t114 = t112 + t113;
  t115 = t7*t3*t8*t23;
  t116 = -1.*t9*t35*t23;
  t117 = -1.*t8*t9*t11*t24;
  t118 = -1.*t3*t9*t13*t25;
  t119 = t7*t65;
  t120 = t115 + t116 + t117 + t118 + t119;
  t121 = -1.*t3*t8*t9*t23;
  t122 = -1.*t7*t35*t23;
  t123 = -1.*t7*t8*t11*t24;
  t124 = -1.*t7*t3*t13*t25;
  t125 = -1.*t9*t65;
  t126 = t121 + t122 + t123 + t124 + t125;
  t127 = -1.*t18*t56;
  t128 = t17*t59;
  t129 = t127 + t128;
  t130 = t9*t13;
  t131 = -1.*t7*t8*t14;
  t132 = t130 + t131;
  t133 = t7*t13;
  t134 = t8*t9*t14;
  t135 = t133 + t134;
  t136 = t8*t9;
  t137 = t7*t13*t14;
  t138 = t136 + t137;
  t139 = t7*t8;
  t140 = -1.*t9*t13*t14;
  t141 = t139 + t140;
  t142 = t9*t11*t13;
  t143 = -1.*t7*t8*t11*t14;
  t144 = t142 + t143;
  t145 = t7*t11*t13;
  t146 = t8*t9*t11*t14;
  t147 = t145 + t146;
  t148 = -1.*t3*t9*t13;
  t149 = t7*t3*t8*t14;
  t150 = t148 + t149;
  t151 = -1.*t7*t3*t13;
  t152 = -1.*t3*t8*t9*t14;
  t153 = t151 + t152;
  t154 = -1.*t17*t56*t22;
  t155 = -1.*t18*t59*t22;
  t156 = -1.*t18*t120;
  t157 = t17*t126;
  t158 = t154 + t155 + t156 + t157;
  t159 = -1.*t18*t138;
  t160 = t17*t141;
  t161 = t159 + t160;
  t162 = t10*t11*t13*t24;
  t163 = t3*t14*t24;
  t164 = -1.*t3*t8*t10*t25;
  t165 = t10*t11*t26;
  t166 = t3*t13*t14*t26;
  t167 = t162 + t163 + t164 + t165 + t166;
  t168 = -1.*t3*t10*t13;
  t169 = t11*t14;
  t170 = t168 + t169;
  t171 = -1.*t7*t3*t13*t23;
  t172 = -1.*t3*t8*t9*t14*t23;
  t173 = t9*t11*t13*t24;
  t174 = -1.*t7*t8*t11*t14*t24;
  t175 = -1.*t3*t8*t9*t25;
  t176 = -1.*t7*t3*t13*t14*t25;
  t177 = t7*t3*t8*t10*t26;
  t178 = t171 + t172 + t173 + t174 + t175 + t176 + t177;
  t179 = t3*t9*t13*t23;
  t180 = -1.*t7*t3*t8*t14*t23;
  t181 = t7*t11*t13*t24;
  t182 = t8*t9*t11*t14*t24;
  t183 = -1.*t7*t3*t8*t25;
  t184 = t3*t9*t13*t14*t25;
  t185 = -1.*t3*t8*t10*t9*t26;
  t186 = t179 + t180 + t181 + t182 + t183 + t184 + t185;
  t187 = t7*t11*t13*t23;
  t188 = t8*t9*t11*t14*t23;
  t189 = t3*t9*t13*t24;
  t190 = -1.*t7*t3*t8*t14*t24;
  t191 = t8*t9*t11*t25;
  t192 = t7*t11*t13*t14*t25;
  t193 = -1.*t7*t8*t10*t11*t26;
  t194 = t187 + t188 + t189 + t190 + t191 + t192 + t193;
  t195 = -1.*t9*t11*t13*t23;
  t196 = t7*t8*t11*t14*t23;
  t197 = t7*t3*t13*t24;
  t198 = t3*t8*t9*t14*t24;
  t199 = t7*t8*t11*t25;
  t200 = -1.*t9*t11*t13*t14*t25;
  t201 = t8*t10*t9*t11*t26;
  t202 = t195 + t196 + t197 + t198 + t199 + t200 + t201;
  t203 = t7*t8*t23;
  t204 = -1.*t9*t13*t14*t23;
  t205 = -1.*t9*t13*t25;
  t206 = t7*t8*t14*t25;
  t207 = t7*t10*t13*t26;
  t208 = t203 + t204 + t205 + t206 + t207;
  t209 = -1.*t8*t9*t23;
  t210 = -1.*t7*t13*t14*t23;
  t211 = -1.*t7*t13*t25;
  t212 = -1.*t8*t9*t14*t25;
  t213 = -1.*t10*t9*t13*t26;
  t214 = t209 + t210 + t211 + t212 + t213;
  t215 = t17*t56;
  t216 = t18*t59;
  t217 = t215 + t216;
  t218 = t17*t132;
  t219 = t18*t135;
  t220 = t218 + t219;
  t221 = t7*t13*t23;
  t222 = t8*t9*t14*t23;
  t223 = t8*t9*t25;
  t224 = t7*t13*t14*t25;
  t225 = -1.*t7*t8*t10*t26;
  t226 = t221 + t222 + t223 + t224 + t225;
  t227 = -1.*t9*t13*t23;
  t228 = t7*t8*t14*t23;
  t229 = t7*t8*t25;
  t230 = -1.*t9*t13*t14*t25;
  t231 = t8*t10*t9*t26;
  t232 = t227 + t228 + t229 + t230 + t231;
  t233 = -1.*t18*t56*t22;
  t234 = t17*t59*t22;
  t235 = t17*t120;
  t236 = t18*t126;
  t237 = t233 + t234 + t235 + t236;
  t238 = -1.*t18*t132;
  t239 = t17*t135;
  t240 = t238 + t239;
  t241 = -1.*t17*t132*t22;
  t242 = -1.*t18*t135*t22;
  t243 = -1.*t18*t226;
  t244 = t17*t232;
  t245 = t241 + t242 + t243 + t244;
  t246 = t3*t10*t13;
  t247 = -1.*t11*t14;
  t248 = t246 + t247;
  t249 = -1.*t10*t11*t13*t24;
  t250 = -1.*t3*t14*t24;
  t251 = t3*t8*t10*t25;
  t252 = -1.*t10*t11*t26;
  t253 = -1.*t3*t13*t14*t26;
  t254 = t249 + t250 + t251 + t252 + t253;
  t255 = -1.*t10*t11*t13;
  t256 = -1.*t3*t14;
  t257 = t255 + t256;
  t258 = -1.*t3*t10*t13*t24;
  t259 = t11*t14*t24;
  t260 = -1.*t8*t10*t11*t25;
  t261 = -1.*t3*t10*t26;
  t262 = t11*t13*t14*t26;
  t263 = t258 + t259 + t260 + t261 + t262;
  t264 = t17*t8*t10*t9;
  t265 = t7*t8*t10*t18;
  t266 = t264 + t265;
  t267 = -1.*t18*t132*t22;
  t268 = t17*t135*t22;
  t269 = t17*t226;
  t270 = t18*t232;
  t271 = t267 + t268 + t269 + t270;
  t272 = -1.*t9*t13;
  t273 = t7*t8*t14;
  t274 = t272 + t273;
  t275 = t8*t9*t11;
  t276 = -1.*t7*t21;
  t277 = t275 + t276;
  t278 = -1.*t7*t35;
  t279 = t66 + t278;
  t280 = t17*t274;
  t281 = -1.*t18*t135;
  t282 = t280 + t281;
  t283 = -1.*t7*t13*t23;
  t284 = -1.*t8*t9*t14*t23;
  t285 = -1.*t8*t9*t25;
  t286 = -1.*t7*t13*t14*t25;
  t287 = t7*t8*t10*t26;
  t288 = t283 + t284 + t285 + t286 + t287;
  t289 = t7*t8*t11*t23;
  t290 = t9*t21*t23;
  t291 = t3*t8*t9*t24;
  t292 = -1.*t9*t11*t13*t25;
  t293 = -1.*t7*t32;
  t294 = t289 + t290 + t291 + t292 + t293;
  t295 = t9*t35*t23;
  t296 = -1.*t7*t65;
  t297 = t86 + t295 + t88 + t89 + t296;
  t298 = -1.*t17*t132;
  t299 = t298 + t281;
  t300 = -1.*t18*t59;
  t301 = -1.*t18*t41;
  t302 = -1.*t17*t135*t22;
  t303 = -1.*t18*t232;
  t304 = -1.*t17*t41*t22;
  t305 = -1.*t18*t53;
  t306 = -1.*t17*t59*t22;
  t307 = -1.*t18*t126;
  p_output1[9]=t111*t129 + t100*t158 + (t17*t68 + t18*t71)*t85 + t80*(-1.*t18*t22*t68 + t17*t22*t71 + t17*t91 + t18*t97);
  p_output1[10]=t106*(-1.*t18*t68 + t17*t71) + t167*t80 + t170*t85 + t114*(-1.*t17*t22*t68 - 1.*t18*t22*t71 - 1.*t18*t91 + t17*t97);
  p_output1[11]=t106*t217 + t114*t237 + t111*t248 + t100*t254;
  p_output1[12]=t158*(t150*t17 + t153*t18) + t129*(t17*t178 + t18*t186 + t153*t17*t22 - 1.*t150*t18*t22) + (t17*t208 + t18*t214 + t141*t17*t22 - 1.*t138*t18*t22)*t240 + (t138*t17 + t141*t18)*t245 + (t17*t194 + t18*t202 + t147*t17*t22 - 1.*t144*t18*t22)*t80 + (t144*t17 + t147*t18)*t85;
  p_output1[13]=t106*(t147*t17 - 1.*t144*t18) + t167*(t153*t17 - 1.*t150*t18) + t114*(-1.*t18*t194 + t17*t202 - 1.*t144*t17*t22 - 1.*t147*t18*t22) + t170*(-1.*t178*t18 + t17*t186 - 1.*t150*t17*t22 - 1.*t153*t18*t22) - 1.*t10*t13*t161*t25 + t10*(-1.*t18*t208 + t17*t214 - 1.*t138*t17*t22 - 1.*t141*t18*t22)*t8 - 1.*t14*t161*t26*t8;
  p_output1[14]=-1.*t10*t100*t11*t13*t25 + t13*t14*t220*t26 - 1.*t10*t13*t271 + t10*t13*t217*t25*t3 + t10*t11*t111*t8 + t10*t11*t217*t24*t8 - 1.*t10*t220*t25*t8 - 1.*t100*t11*t14*t26*t8 - 1.*t10*t237*t3*t8 + t10*t100*t24*t3*t8 + t14*t217*t26*t3*t8;
  p_output1[15]=t158*(t17*t248*t7 - 1.*t18*t248*t9) + t129*(-1.*t18*t22*t248*t7 - 1.*t18*t23*t248*t7 + t17*t254*t7 - 1.*t17*t22*t248*t9 - 1.*t17*t23*t248*t9 - 1.*t18*t254*t9) + t85*(t17*t257*t7 - 1.*t18*t257*t9) + t80*(-1.*t18*t22*t257*t7 - 1.*t18*t23*t257*t7 + t17*t263*t7 - 1.*t17*t22*t257*t9 - 1.*t17*t23*t257*t9 - 1.*t18*t263*t9) + t245*(-1.*t10*t17*t7*t8 + t10*t18*t8*t9) + t240*(t10*t13*t17*t25*t7 + t10*t18*t22*t7*t8 + t10*t18*t23*t7*t8 + t14*t17*t26*t7*t8 - 1.*t10*t13*t18*t25*t9 + t10*t17*t22*t8*t9 + t10*t17*t23*t8*t9 - 1.*t14*t18*t26*t8*t9);
  p_output1[16]=-1.*t10*t13*t25*t266 - 1.*t14*t26*t266*t8 + t167*(-1.*t18*t248*t7 - 1.*t17*t248*t9) + t170*(-1.*t17*t22*t248*t7 - 1.*t17*t23*t248*t7 - 1.*t18*t254*t7 + t18*t22*t248*t9 + t18*t23*t248*t9 - 1.*t17*t254*t9) + t106*(-1.*t18*t257*t7 - 1.*t17*t257*t9) + t114*(-1.*t17*t22*t257*t7 - 1.*t17*t23*t257*t7 - 1.*t18*t263*t7 + t18*t22*t257*t9 + t18*t23*t257*t9 - 1.*t17*t263*t9) + t10*t8*(-1.*t10*t13*t18*t25*t7 + t10*t17*t22*t7*t8 + t10*t17*t23*t7*t8 - 1.*t14*t18*t26*t7*t8 - 1.*t10*t13*t17*t25*t9 - 1.*t10*t18*t22*t8*t9 - 1.*t10*t18*t23*t8*t9 - 1.*t14*t17*t26*t8*t9);
  p_output1[17]=t111*t21 + t13*t14*t220*t25 + t100*t32 + t237*t35 + t217*t65 - 1.*t10*t220*t26*t8 - 1.*t14*t271*t8;
  p_output1[18]=t245*(t239 + t18*t274) + t158*(t128 + t18*t279) + t240*(t242 + t244 + t17*t22*t274 + t18*t288) + t129*(t155 + t157 + t17*t22*t279 + t18*t297) + t80*(t17*t22*t277 + t18*t294 + t82 + t84) + (t18*t277 + t79)*t85;
  p_output1[19]=-1.*t10*t13*t25*t282 + t167*(t17*t279 + t300) + t106*(t17*t277 + t301) + t114*(-1.*t18*t22*t277 + t17*t294 + t304 + t305) + t170*(-1.*t18*t22*t279 + t17*t297 + t306 + t307) - 1.*t14*t26*t282*t8 + t10*(-1.*t18*t22*t274 + t17*t288 + t302 + t303)*t8;
  p_output1[21]=2.*t129*t158 + 2.*t240*t245 + 2.*t80*t85;
  p_output1[22]=-1.*t10*t13*t25*t299 + t106*(t301 - 1.*t17*t38) + t114*(t304 + t305 + t18*t22*t38 - 1.*t17*t47) + t167*(t300 - 1.*t17*t56) + t170*(-1.*t120*t17 + t306 + t307 + t18*t22*t56) - 1.*t14*t26*t299*t8 + t10*(t132*t18*t22 - 1.*t17*t226 + t302 + t303)*t8;
}



#ifdef MATLAB_MEX_FILE

#include "mex.h"
#include "matrix.h"

/*
 * Main function
 */
void mexFunction( int nlhs, mxArray *plhs[],
                  int nrhs, const mxArray *prhs[] )
{
  size_t mrows, ncols;

  double *x;
  double *p_output1;

  /*  Check for proper number of arguments.  */ 
  if( nrhs != 1)
    {
      mexErrMsgIdAndTxt("MATLAB:MShaped:invalidNumInputs", "One input(s) required (x).");
    }
  else if( nlhs > 1)
    {
      mexErrMsgIdAndTxt("MATLAB:MShaped:maxlhs", "Too many output arguments.");
    }

  /*  The input must be a noncomplex double vector or scaler.  */
  mrows = mxGetM(prhs[0]);
  ncols = mxGetN(prhs[0]);
  if( !mxIsDouble(prhs[0]) || mxIsComplex(prhs[0]) ||
    ( !(mrows == 44 && ncols == 1) && 
      !(mrows == 1 && ncols == 44))) 
    {
      mexErrMsgIdAndTxt( "MATLAB:MShaped:inputNotRealVector", "x is wrong.");
    }

  /*  Assign pointers to each input.  */
  x = mxGetPr(prhs[0]);
   


   
  /*  Create matrices for return arguments.  */
  plhs[0] = mxCreateDoubleMatrix((mwSize) 3, (mwSize) 22, mxREAL);
  p_output1 = mxGetPr(plhs[0]);


  /* Call the calculation subroutine. */
  output1(p_output1,x);


}

#else // MATLAB_MEX_FILE

#include "dJw_body_hipabductionleft.hh"

namespace symbolic_expression
{
namespace basic
{

void dJw_body_hipabductionleft_raw(double *p_output1, const double *x)
{
  // Call Subroutines
  output1(p_output1, x);

}

}
}

#endif // MATLAB_MEX_FILE
